Common files:

webgl-utils.js: standard utilities from google to set up a webgl context

MV.js: our matrix/vector package. Documentation on website，加了注解并修改了部分

initShaders.js: functions to initialize shaders in the html file

